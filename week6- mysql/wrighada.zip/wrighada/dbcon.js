const mysql = require('mysql');

const osu = {
	connectionLimit : 10,
	host            : 'classmysql.engr.oregonstate.edu',
	user            : 'cs290_wrighada',
	password        : '6woLM3uLZYuG5SBZ',
    database        : 'cs290_wrighada',
    dateStrings     : 'true'
};

let pool = mysql.createPool(osu);

module.exports.pool = pool;